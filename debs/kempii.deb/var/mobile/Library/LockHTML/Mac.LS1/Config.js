/*
Original code by Dacal --> Modified code by Schnedi  // D0 NOT REMOVE THIS LINE //
*/

var Clock = "12h";	       // choose between "12h" or "24h".
var Lang = "en";	           // choose between "ca", "en", "de" or "fr".